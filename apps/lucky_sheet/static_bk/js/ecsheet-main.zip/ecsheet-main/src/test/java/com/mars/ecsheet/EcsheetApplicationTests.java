package com.mars.ecsheet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcsheetApplicationTests {

    @Test
    void contextLoads() {
    }

}
